package test;

public class Test02 {

	public Test02() {
		Plus p = new Plus(13.2, 13.5);
		p.toPrint();
		Semo s = new Semo(7, 3);
		System.out.println(s.area());
		Nemo n = new Nemo();
		System.out.println(n);
		
	}

	public static void main(String[] args) {
		new Test02();
	}

}
