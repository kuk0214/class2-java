package test;

public class MemberSQL {

	public MemberSQL() {
		
	}

	public static void main(String[] args) {
		new MemberSQL();
	}

}
