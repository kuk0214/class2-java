package test;

import java.util.*;
public class HashMapTest {

	public HashMapTest() {
		HashMap map = new HashMap();
		map.put("이름", "홍길동");
		map.put("나이", 24);
		map.put("성별", "남자");
		
		Set set = map.keySet();
		Iterator itor = set.iterator();
		while(itor.hasNext()) {
			String key = (String) itor.next();
			System.out.println(key + " - " + map.get(key));
		}
		
	}

	public static void main(String[] args) {
		new HashMapTest();
	}

}
