package test;

public class Plus implements Calc {
	private double no1, no2, result;
	public Plus() {}
	
	public Plus(double no1, double no2) {
		this.no1 = no1;
		this.no2 = no2;
	}
	
	public double getNo1() {
		return no1;
	}

	public void setNo1(double no1) {
		this.no1 = no1;
	}

	public double getNo2() {
		return no2;
	}

	public void setNo2(double no2) {
		this.no2 = no2;
	}

	@Override
	public double cal() {
		result = no1 + no2;
		return result;
	}

	public void toPrint() {
		System.out.println(no1 + " + " + no2 + " = " + cal());
	}
	
}
