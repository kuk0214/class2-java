package test;

public class Figure {
	public float area() {
		return 1F;
	}
}
