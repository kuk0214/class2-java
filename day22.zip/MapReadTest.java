package day22;

/*
	ObjectTest02에서 저장한 map.txt 
	파일을 읽어서 출력해보자.
 */

import java.io.*;
import java.util.*;
public class MapReadTest {

	public MapReadTest() {
		// 스트림 준비
		FileInputStream fin = null;
		ObjectInputStream oin = null;
		try {
			// 스트림 만들고
			fin = new FileInputStream("src/day22/data/map.txt");
			oin = new ObjectInputStream(fin);
			
			// 데이터 꺼내고
			HashMap map = (HashMap) oin.readObject();
			// 출력하고
			System.out.println(map);
			
			System.out.println("name : " + map.get("name"));
			System.out.println("tel : " + map.get("tel"));
			System.out.println("mail : " + map.get("mail"));
			System.out.println("addr : " + map.get("addr"));
			System.out.println("gen : " + map.get("gen"));
			System.out.println("age : " + map.get("age"));
			System.out.println("height : " + map.get("height"));
			System.out.println();
			Set set = map.keySet();
			Iterator itor = set.iterator();
			while(itor.hasNext()) {
				String key = (String) itor.next();
				System.out.println(key + " - " + map.get(key));
			}
			
			System.out.println();
			Set set2 = map.entrySet();
			ArrayList list = new ArrayList(set2);
			for(int i = 0 ; i < list.size() ; i++ ) {
				System.out.println(list.get(i));
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				oin.close();
				fin.close();
			} catch(Exception e) {}
		}
	}

	public static void main(String[] args) {
		new MapReadTest();
	}

}
