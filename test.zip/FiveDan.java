package test;

public class FiveDan {

	public static void main(String[] args) {
		int dan = 5;
		int gob = 1;
		do {
			System.out.println(dan + " X " + gob + " = " + (dan * gob));
			gob++;
		} while(gob < 10);
	}

}
