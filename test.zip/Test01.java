package test;

public class Test01 {

	public Test01() {
		boolean
		char
		byte
		short
		int
		long
		float
		double
		int num = 75000;
		private - 그 클래스내에서만
		생략 - 패키지내에서만
		protected - 패키지내 + 상속받은 클래스에서 
		public - 모두
		
		클래스이름에 첫번째가 문자가 아니고 사용할 수 없는 특수 문자다
		변수 초기화가 되지 않았다?
		main 함수가 없다?
		
		
		int a = 10;
		int b = ++a + ++a;
		//b = 11 + 12 = 23
		System.out.println("a : 12 | " + a + "\nb : " + b);
		int c = 10;
		int d = ++c + c++;
		//d = 11 + 11 = 22
		System.out.println("c : 12 | " + c + "\nd : " + d);
		int e = 10;
		int f = e++ + e++;
		//f = 10 + 11 = 21
		System.out.println("e : 12 | " + e + "\nd : " + f);
	}

	public static void main(String[] args) {
		new Test01();
	}

}
