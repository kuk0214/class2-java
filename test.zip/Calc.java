package test;

public interface Calc {
	double cal();
}
